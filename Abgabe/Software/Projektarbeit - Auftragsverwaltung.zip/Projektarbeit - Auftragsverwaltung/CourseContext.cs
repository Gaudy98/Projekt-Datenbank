﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Projektarbeit___Auftragsverwaltung.Model;
using DbContext = Microsoft.EntityFrameworkCore.DbContext;

namespace Projektarbeit___Auftragsverwaltung
{
    class CourseContext : DbContext
    {
        public Microsoft.EntityFrameworkCore.DbSet<Articels> Articels { get; set; }

         public Microsoft.EntityFrameworkCore.DbSet<Articelsgrupps> Articelsgrupps { get; set; }

         public Microsoft.EntityFrameworkCore.DbSet<Customer> Customers { get; set; }

         public Microsoft.EntityFrameworkCore.DbSet<Order> Orders { get; set; }

         public Microsoft.EntityFrameworkCore.DbSet<Quartal> Quartal { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=.; Database=ProjektArbeit; Trusted_Connection=True");


        }


    }
}
