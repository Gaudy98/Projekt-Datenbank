﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projektarbeit___Auftragsverwaltung
{
    public partial class Form_ArticelsGruppe : Form
    {
        private Form_Dashbord form_Dashbord;
        

        public Form_ArticelsGruppe(Form_Dashbord form_Dashbord)
        {
            InitializeComponent();
            this.form_Dashbord = form_Dashbord;
        }
        void Clear()
        {
            TxtArticelGrup.Text = " ";
        }

        private void Form_ArticelsGruppe_Load(object sender, EventArgs e)
        {
            Clear();
            PopulateDataGridView();
        }

        private void LblDashboard_Click(object sender, EventArgs e)
        {
            form_Dashbord.Show();
            this.Close();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            form_Dashbord.Show();
            base.OnFormClosing(e);
        }

        void PopulateDataGridView()
        {
            using (var Context = new CourseContext())
            {
                GrdArtGroup.DataSource = Context.Articelsgrupps.ToList<Articelsgrupps>();

            }
        }

        private void CmdCreateCustomer_Click(object sender, EventArgs e)
        {
            using (var Context = new CourseContext())
            {
                var model = new Articelsgrupps();

                model.Name = TxtArticelGrup.Text.Trim();
                
                Context.Articelsgrupps.Add(model);
                Context.SaveChanges();

                Clear();
                MessageBox.Show("Submtted Succesfully");

                PopulateDataGridView();
            }
        }

        private void CmdDeleteCustomer_Click(object sender, EventArgs e)
        {
            int index = GrdArtGroup.CurrentCell.RowIndex;

            using (var context = new CourseContext())
            {
                var artGroup  = context.Articelsgrupps.Find(index);
                context.Articelsgrupps.Remove(artGroup);
                context.SaveChanges();

                PopulateDataGridView();
                MessageBox.Show("Delate");

            }
        }
    }
}
