﻿
namespace Projektarbeit___Auftragsverwaltung
{
    partial class Form_Order
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.TxtSearchDB = new System.Windows.Forms.TextBox();
            this.CmdDeleteOrder = new System.Windows.Forms.Button();
            this.CmdModifyOrder = new System.Windows.Forms.Button();
            this.CmdCreateOrder = new System.Windows.Forms.Button();
            this.LblDashboard = new System.Windows.Forms.Label();
            this.GrdOrder = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.auftragsnummerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionNumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.artikelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.anzahlDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.txtOrdernum = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtOrderPosition = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtDate = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtOrderNr = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.Cmd_Search = new System.Windows.Forms.Button();
            this.CmbArticels = new System.Windows.Forms.ComboBox();
            this.articelsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.CmbCustomer = new System.Windows.Forms.ComboBox();
            this.customerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.GrdOrder)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.articelsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // TxtSearchDB
            // 
            this.TxtSearchDB.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Bold);
            this.TxtSearchDB.Location = new System.Drawing.Point(674, 150);
            this.TxtSearchDB.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.TxtSearchDB.Name = "TxtSearchDB";
            this.TxtSearchDB.Size = new System.Drawing.Size(862, 71);
            this.TxtSearchDB.TabIndex = 52;
            // 
            // CmdDeleteOrder
            // 
            this.CmdDeleteOrder.Location = new System.Drawing.Point(607, 925);
            this.CmdDeleteOrder.Name = "CmdDeleteOrder";
            this.CmdDeleteOrder.Size = new System.Drawing.Size(236, 48);
            this.CmdDeleteOrder.TabIndex = 51;
            this.CmdDeleteOrder.Text = "Delete Selected";
            this.CmdDeleteOrder.UseVisualStyleBackColor = true;
            this.CmdDeleteOrder.Click += new System.EventHandler(this.CmdDeleteCustomer_Click);
            // 
            // CmdModifyOrder
            // 
            this.CmdModifyOrder.Location = new System.Drawing.Point(338, 925);
            this.CmdModifyOrder.Name = "CmdModifyOrder";
            this.CmdModifyOrder.Size = new System.Drawing.Size(239, 48);
            this.CmdModifyOrder.TabIndex = 50;
            this.CmdModifyOrder.Text = "Modify Selected";
            this.CmdModifyOrder.UseVisualStyleBackColor = true;
            // 
            // CmdCreateOrder
            // 
            this.CmdCreateOrder.Location = new System.Drawing.Point(52, 925);
            this.CmdCreateOrder.Name = "CmdCreateOrder";
            this.CmdCreateOrder.Size = new System.Drawing.Size(246, 48);
            this.CmdCreateOrder.TabIndex = 49;
            this.CmdCreateOrder.Text = "Add New Customer";
            this.CmdCreateOrder.UseVisualStyleBackColor = true;
            this.CmdCreateOrder.Click += new System.EventHandler(this.CmdCreateCustomer_Click);
            // 
            // LblDashboard
            // 
            this.LblDashboard.AutoSize = true;
            this.LblDashboard.BackColor = System.Drawing.Color.Transparent;
            this.LblDashboard.Font = new System.Drawing.Font("Rage Italic", 20.1F, System.Drawing.FontStyle.Bold);
            this.LblDashboard.ForeColor = System.Drawing.Color.DarkGray;
            this.LblDashboard.Location = new System.Drawing.Point(58, 91);
            this.LblDashboard.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.LblDashboard.Name = "LblDashboard";
            this.LblDashboard.Size = new System.Drawing.Size(300, 86);
            this.LblDashboard.TabIndex = 48;
            this.LblDashboard.Text = "Dashboard";
            this.LblDashboard.UseMnemonic = false;
            this.LblDashboard.Click += new System.EventHandler(this.LblDashboard_Click);
            // 
            // GrdOrder
            // 
            this.GrdOrder.AllowUserToAddRows = false;
            this.GrdOrder.AllowUserToDeleteRows = false;
            this.GrdOrder.AutoGenerateColumns = false;
            this.GrdOrder.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GrdOrder.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.auftragsnummerDataGridViewTextBoxColumn,
            this.dateDataGridViewTextBoxColumn,
            this.customerDataGridViewTextBoxColumn,
            this.positionNumDataGridViewTextBoxColumn,
            this.artikelDataGridViewTextBoxColumn,
            this.anzahlDataGridViewTextBoxColumn});
            this.GrdOrder.DataSource = this.orderBindingSource;
            this.GrdOrder.Location = new System.Drawing.Point(674, 266);
            this.GrdOrder.Name = "GrdOrder";
            this.GrdOrder.ReadOnly = true;
            this.GrdOrder.RowHeadersWidth = 102;
            this.GrdOrder.Size = new System.Drawing.Size(1314, 587);
            this.GrdOrder.TabIndex = 47;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            this.idDataGridViewTextBoxColumn.Width = 250;
            // 
            // auftragsnummerDataGridViewTextBoxColumn
            // 
            this.auftragsnummerDataGridViewTextBoxColumn.DataPropertyName = "Auftragsnummer";
            this.auftragsnummerDataGridViewTextBoxColumn.HeaderText = "Auftragsnummer";
            this.auftragsnummerDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.auftragsnummerDataGridViewTextBoxColumn.Name = "auftragsnummerDataGridViewTextBoxColumn";
            this.auftragsnummerDataGridViewTextBoxColumn.ReadOnly = true;
            this.auftragsnummerDataGridViewTextBoxColumn.Width = 250;
            // 
            // dateDataGridViewTextBoxColumn
            // 
            this.dateDataGridViewTextBoxColumn.DataPropertyName = "Date";
            this.dateDataGridViewTextBoxColumn.HeaderText = "Date";
            this.dateDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.dateDataGridViewTextBoxColumn.Name = "dateDataGridViewTextBoxColumn";
            this.dateDataGridViewTextBoxColumn.ReadOnly = true;
            this.dateDataGridViewTextBoxColumn.Width = 250;
            // 
            // customerDataGridViewTextBoxColumn
            // 
            this.customerDataGridViewTextBoxColumn.DataPropertyName = "Customer";
            this.customerDataGridViewTextBoxColumn.HeaderText = "Customer";
            this.customerDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.customerDataGridViewTextBoxColumn.Name = "customerDataGridViewTextBoxColumn";
            this.customerDataGridViewTextBoxColumn.ReadOnly = true;
            this.customerDataGridViewTextBoxColumn.Width = 250;
            // 
            // positionNumDataGridViewTextBoxColumn
            // 
            this.positionNumDataGridViewTextBoxColumn.DataPropertyName = "PositionNum";
            this.positionNumDataGridViewTextBoxColumn.HeaderText = "PositionNum";
            this.positionNumDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.positionNumDataGridViewTextBoxColumn.Name = "positionNumDataGridViewTextBoxColumn";
            this.positionNumDataGridViewTextBoxColumn.ReadOnly = true;
            this.positionNumDataGridViewTextBoxColumn.Width = 250;
            // 
            // artikelDataGridViewTextBoxColumn
            // 
            this.artikelDataGridViewTextBoxColumn.DataPropertyName = "Artikel";
            this.artikelDataGridViewTextBoxColumn.HeaderText = "Artikel";
            this.artikelDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.artikelDataGridViewTextBoxColumn.Name = "artikelDataGridViewTextBoxColumn";
            this.artikelDataGridViewTextBoxColumn.ReadOnly = true;
            this.artikelDataGridViewTextBoxColumn.Width = 250;
            // 
            // anzahlDataGridViewTextBoxColumn
            // 
            this.anzahlDataGridViewTextBoxColumn.DataPropertyName = "Anzahl";
            this.anzahlDataGridViewTextBoxColumn.HeaderText = "Anzahl";
            this.anzahlDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.anzahlDataGridViewTextBoxColumn.Name = "anzahlDataGridViewTextBoxColumn";
            this.anzahlDataGridViewTextBoxColumn.ReadOnly = true;
            this.anzahlDataGridViewTextBoxColumn.Width = 250;
            // 
            // orderBindingSource
            // 
            this.orderBindingSource.DataSource = typeof(Projektarbeit___Auftragsverwaltung.Model.Order);
            // 
            // txtOrdernum
            // 
            this.txtOrdernum.Location = new System.Drawing.Point(230, 633);
            this.txtOrdernum.Name = "txtOrdernum";
            this.txtOrdernum.Size = new System.Drawing.Size(384, 38);
            this.txtOrdernum.TabIndex = 69;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(67, 639);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 32);
            this.label6.TabIndex = 76;
            this.label6.Text = "Anzahl";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(67, 567);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 32);
            this.label5.TabIndex = 75;
            this.label5.Text = "Artikel";
            // 
            // txtOrderPosition
            // 
            this.txtOrderPosition.Location = new System.Drawing.Point(230, 484);
            this.txtOrderPosition.Name = "txtOrderPosition";
            this.txtOrderPosition.Size = new System.Drawing.Size(384, 38);
            this.txtOrderPosition.TabIndex = 67;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(67, 490);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 32);
            this.label4.TabIndex = 74;
            this.label4.Text = "position";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(67, 414);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 32);
            this.label3.TabIndex = 73;
            this.label3.Text = "Kunde";
            // 
            // txtDate
            // 
            this.txtDate.Location = new System.Drawing.Point(230, 334);
            this.txtDate.Name = "txtDate";
            this.txtDate.Size = new System.Drawing.Size(384, 38);
            this.txtDate.TabIndex = 64;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(67, 340);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 32);
            this.label2.TabIndex = 72;
            this.label2.Text = "Datum";
            // 
            // txtOrderNr
            // 
            this.txtOrderNr.Location = new System.Drawing.Point(230, 266);
            this.txtOrderNr.Name = "txtOrderNr";
            this.txtOrderNr.Size = new System.Drawing.Size(384, 38);
            this.txtOrderNr.TabIndex = 63;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(67, 272);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(158, 32);
            this.label9.TabIndex = 65;
            this.label9.Text = "AuftragsNr.";
            // 
            // Cmd_Search
            // 
            this.Cmd_Search.Location = new System.Drawing.Point(1601, 150);
            this.Cmd_Search.Name = "Cmd_Search";
            this.Cmd_Search.Size = new System.Drawing.Size(264, 66);
            this.Cmd_Search.TabIndex = 79;
            this.Cmd_Search.Text = "Suche";
            this.Cmd_Search.UseVisualStyleBackColor = true;
            // 
            // CmbArticels
            // 
            this.CmbArticels.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.articelsBindingSource, "Bezeichnung", true));
            this.CmbArticels.DataSource = this.articelsBindingSource;
            this.CmbArticels.DisplayMember = "Bezeichnung";
            this.CmbArticels.FormattingEnabled = true;
            this.CmbArticels.Location = new System.Drawing.Point(233, 564);
            this.CmbArticels.Name = "CmbArticels";
            this.CmbArticels.Size = new System.Drawing.Size(381, 39);
            this.CmbArticels.TabIndex = 81;
            this.CmbArticels.ValueMember = "Id";
            this.CmbArticels.SelectedIndexChanged += new System.EventHandler(this.CmbArticels_SelectedIndexChanged);
            // 
            // articelsBindingSource
            // 
            this.articelsBindingSource.DataSource = typeof(Projektarbeit___Auftragsverwaltung.Model.Articels);
            // 
            // CmbCustomer
            // 
            this.CmbCustomer.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.customerBindingSource, "Name", true));
            this.CmbCustomer.DataSource = this.customerBindingSource;
            this.CmbCustomer.DisplayMember = "Name";
            this.CmbCustomer.FormattingEnabled = true;
            this.CmbCustomer.Location = new System.Drawing.Point(233, 407);
            this.CmbCustomer.Name = "CmbCustomer";
            this.CmbCustomer.Size = new System.Drawing.Size(381, 39);
            this.CmbCustomer.TabIndex = 82;
            this.CmbCustomer.ValueMember = "Id";
            this.CmbCustomer.SelectedIndexChanged += new System.EventHandler(this.CmbCustomer_SelectedIndexChanged);
            // 
            // customerBindingSource
            // 
            this.customerBindingSource.DataSource = typeof(Projektarbeit___Auftragsverwaltung.Model.Customer);
            // 
            // Form_Order
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2103, 1064);
            this.Controls.Add(this.CmbCustomer);
            this.Controls.Add(this.CmbArticels);
            this.Controls.Add(this.Cmd_Search);
            this.Controls.Add(this.txtOrdernum);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtOrderPosition);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtDate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtOrderNr);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.TxtSearchDB);
            this.Controls.Add(this.CmdDeleteOrder);
            this.Controls.Add(this.CmdModifyOrder);
            this.Controls.Add(this.CmdCreateOrder);
            this.Controls.Add(this.LblDashboard);
            this.Controls.Add(this.GrdOrder);
            this.Name = "Form_Order";
            this.Text = "Aufträge";
            this.Load += new System.EventHandler(this.Form_Order_Load);
            ((System.ComponentModel.ISupportInitialize)(this.GrdOrder)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.articelsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox TxtSearchDB;
        private System.Windows.Forms.Button CmdDeleteOrder;
        private System.Windows.Forms.Button CmdModifyOrder;
        private System.Windows.Forms.Button CmdCreateOrder;
        private System.Windows.Forms.Label LblDashboard;
        private System.Windows.Forms.DataGridView GrdOrder;
        private System.Windows.Forms.TextBox txtOrdernum;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtOrderPosition;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtDate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtOrderNr;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button Cmd_Search;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn auftragsnummerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionNumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn artikelDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn anzahlDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource orderBindingSource;
        private System.Windows.Forms.ComboBox CmbArticels;
        private System.Windows.Forms.BindingSource articelsBindingSource;
        private System.Windows.Forms.ComboBox CmbCustomer;
        private System.Windows.Forms.BindingSource customerBindingSource;
    }
}