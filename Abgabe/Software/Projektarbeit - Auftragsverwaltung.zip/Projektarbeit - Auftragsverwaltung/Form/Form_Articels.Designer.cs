﻿
namespace Projektarbeit___Auftragsverwaltung
{
    partial class Form_Articels
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.TxtSearchDB = new System.Windows.Forms.TextBox();
            this.CmdDeleteCustomer = new System.Windows.Forms.Button();
            this.CmdModifyCustomer = new System.Windows.Forms.Button();
            this.CmdCreateCustomer = new System.Windows.Forms.Button();
            this.LblDashboard = new System.Windows.Forms.Label();
            this.GrdArt = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.artikelNrDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bezeichnungDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.preisDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.artikelGruppeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.articelsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label4 = new System.Windows.Forms.Label();
            this.txtPreis = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtArtName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtArtNr = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.CmbArtGroup = new System.Windows.Forms.ComboBox();
            this.articelsgruppsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.GrdArt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.articelsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.articelsgruppsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // TxtSearchDB
            // 
            this.TxtSearchDB.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Bold);
            this.TxtSearchDB.Location = new System.Drawing.Point(680, 139);
            this.TxtSearchDB.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.TxtSearchDB.Name = "TxtSearchDB";
            this.TxtSearchDB.Size = new System.Drawing.Size(862, 71);
            this.TxtSearchDB.TabIndex = 52;
            // 
            // CmdDeleteCustomer
            // 
            this.CmdDeleteCustomer.Location = new System.Drawing.Point(723, 914);
            this.CmdDeleteCustomer.Name = "CmdDeleteCustomer";
            this.CmdDeleteCustomer.Size = new System.Drawing.Size(236, 48);
            this.CmdDeleteCustomer.TabIndex = 51;
            this.CmdDeleteCustomer.Text = "Delete Selected";
            this.CmdDeleteCustomer.UseVisualStyleBackColor = true;
            this.CmdDeleteCustomer.Click += new System.EventHandler(this.CmdDeleteCustomer_Click);
            // 
            // CmdModifyCustomer
            // 
            this.CmdModifyCustomer.Location = new System.Drawing.Point(419, 914);
            this.CmdModifyCustomer.Name = "CmdModifyCustomer";
            this.CmdModifyCustomer.Size = new System.Drawing.Size(239, 48);
            this.CmdModifyCustomer.TabIndex = 50;
            this.CmdModifyCustomer.Text = "Modify Selected";
            this.CmdModifyCustomer.UseVisualStyleBackColor = true;
            // 
            // CmdCreateCustomer
            // 
            this.CmdCreateCustomer.Location = new System.Drawing.Point(68, 914);
            this.CmdCreateCustomer.Name = "CmdCreateCustomer";
            this.CmdCreateCustomer.Size = new System.Drawing.Size(246, 48);
            this.CmdCreateCustomer.TabIndex = 49;
            this.CmdCreateCustomer.Text = "Add New Customer";
            this.CmdCreateCustomer.UseVisualStyleBackColor = true;
            this.CmdCreateCustomer.Click += new System.EventHandler(this.CmdCreateCustomer_Click);
            // 
            // LblDashboard
            // 
            this.LblDashboard.AutoSize = true;
            this.LblDashboard.BackColor = System.Drawing.Color.Transparent;
            this.LblDashboard.Font = new System.Drawing.Font("Rage Italic", 20.1F, System.Drawing.FontStyle.Bold);
            this.LblDashboard.ForeColor = System.Drawing.Color.DarkGray;
            this.LblDashboard.Location = new System.Drawing.Point(64, 80);
            this.LblDashboard.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.LblDashboard.Name = "LblDashboard";
            this.LblDashboard.Size = new System.Drawing.Size(300, 86);
            this.LblDashboard.TabIndex = 48;
            this.LblDashboard.Text = "Dashboard";
            this.LblDashboard.UseMnemonic = false;
            this.LblDashboard.Click += new System.EventHandler(this.LblDashboard_Click);
            // 
            // GrdArt
            // 
            this.GrdArt.AllowUserToAddRows = false;
            this.GrdArt.AllowUserToDeleteRows = false;
            this.GrdArt.AutoGenerateColumns = false;
            this.GrdArt.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GrdArt.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.artikelNrDataGridViewTextBoxColumn,
            this.bezeichnungDataGridViewTextBoxColumn,
            this.preisDataGridViewTextBoxColumn,
            this.artikelGruppeDataGridViewTextBoxColumn});
            this.GrdArt.DataSource = this.articelsBindingSource;
            this.GrdArt.Location = new System.Drawing.Point(680, 256);
            this.GrdArt.Name = "GrdArt";
            this.GrdArt.ReadOnly = true;
            this.GrdArt.RowHeadersWidth = 102;
            this.GrdArt.Size = new System.Drawing.Size(1357, 573);
            this.GrdArt.TabIndex = 47;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            this.idDataGridViewTextBoxColumn.Width = 250;
            // 
            // artikelNrDataGridViewTextBoxColumn
            // 
            this.artikelNrDataGridViewTextBoxColumn.DataPropertyName = "ArtikelNr";
            this.artikelNrDataGridViewTextBoxColumn.HeaderText = "ArtikelNr";
            this.artikelNrDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.artikelNrDataGridViewTextBoxColumn.Name = "artikelNrDataGridViewTextBoxColumn";
            this.artikelNrDataGridViewTextBoxColumn.ReadOnly = true;
            this.artikelNrDataGridViewTextBoxColumn.Width = 250;
            // 
            // bezeichnungDataGridViewTextBoxColumn
            // 
            this.bezeichnungDataGridViewTextBoxColumn.DataPropertyName = "Bezeichnung";
            this.bezeichnungDataGridViewTextBoxColumn.HeaderText = "Bezeichnung";
            this.bezeichnungDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.bezeichnungDataGridViewTextBoxColumn.Name = "bezeichnungDataGridViewTextBoxColumn";
            this.bezeichnungDataGridViewTextBoxColumn.ReadOnly = true;
            this.bezeichnungDataGridViewTextBoxColumn.Width = 250;
            // 
            // preisDataGridViewTextBoxColumn
            // 
            this.preisDataGridViewTextBoxColumn.DataPropertyName = "Preis";
            this.preisDataGridViewTextBoxColumn.HeaderText = "Preis";
            this.preisDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.preisDataGridViewTextBoxColumn.Name = "preisDataGridViewTextBoxColumn";
            this.preisDataGridViewTextBoxColumn.ReadOnly = true;
            this.preisDataGridViewTextBoxColumn.Width = 250;
            // 
            // artikelGruppeDataGridViewTextBoxColumn
            // 
            this.artikelGruppeDataGridViewTextBoxColumn.DataPropertyName = "ArtikelGruppe";
            this.artikelGruppeDataGridViewTextBoxColumn.HeaderText = "ArtikelGruppe";
            this.artikelGruppeDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.artikelGruppeDataGridViewTextBoxColumn.Name = "artikelGruppeDataGridViewTextBoxColumn";
            this.artikelGruppeDataGridViewTextBoxColumn.ReadOnly = true;
            this.artikelGruppeDataGridViewTextBoxColumn.Width = 250;
            // 
            // articelsBindingSource
            // 
            this.articelsBindingSource.DataSource = typeof(Projektarbeit___Auftragsverwaltung.Model.Articels);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 474);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(197, 32);
            this.label4.TabIndex = 68;
            this.label4.Text = "Artikel Gruppe";
            // 
            // txtPreis
            // 
            this.txtPreis.Location = new System.Drawing.Point(236, 392);
            this.txtPreis.Name = "txtPreis";
            this.txtPreis.Size = new System.Drawing.Size(384, 38);
            this.txtPreis.TabIndex = 63;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(73, 398);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 32);
            this.label3.TabIndex = 67;
            this.label3.Text = "Preis";
            // 
            // txtArtName
            // 
            this.txtArtName.Location = new System.Drawing.Point(236, 318);
            this.txtArtName.Name = "txtArtName";
            this.txtArtName.Size = new System.Drawing.Size(384, 38);
            this.txtArtName.TabIndex = 61;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(62, 324);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(181, 32);
            this.label2.TabIndex = 66;
            this.label2.Text = "Bezeichnung";
            // 
            // txtArtNr
            // 
            this.txtArtNr.Location = new System.Drawing.Point(236, 250);
            this.txtArtNr.Name = "txtArtNr";
            this.txtArtNr.Size = new System.Drawing.Size(384, 38);
            this.txtArtNr.TabIndex = 60;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(73, 256);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 32);
            this.label9.TabIndex = 62;
            this.label9.Text = "ArtNr";
            // 
            // CmbArtGroup
            // 
            this.CmbArtGroup.DataSource = this.articelsgruppsBindingSource;
            this.CmbArtGroup.DisplayMember = "Name";
            this.CmbArtGroup.FormattingEnabled = true;
            this.CmbArtGroup.Location = new System.Drawing.Point(236, 467);
            this.CmbArtGroup.Name = "CmbArtGroup";
            this.CmbArtGroup.Size = new System.Drawing.Size(384, 39);
            this.CmbArtGroup.TabIndex = 69;
            this.CmbArtGroup.ValueMember = "Id";
            // 
            // articelsgruppsBindingSource
            // 
            this.articelsgruppsBindingSource.DataSource = typeof(Projektarbeit___Auftragsverwaltung.Model.Articelsgrupps);
            // 
            // Form_Articels
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2114, 1043);
            this.Controls.Add(this.CmbArtGroup);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtPreis);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtArtName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtArtNr);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.TxtSearchDB);
            this.Controls.Add(this.CmdDeleteCustomer);
            this.Controls.Add(this.CmdModifyCustomer);
            this.Controls.Add(this.CmdCreateCustomer);
            this.Controls.Add(this.LblDashboard);
            this.Controls.Add(this.GrdArt);
            this.Name = "Form_Articels";
            this.Text = "Artikel";
            this.Load += new System.EventHandler(this.Form_Articels_Load);
            ((System.ComponentModel.ISupportInitialize)(this.GrdArt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.articelsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.articelsgruppsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox TxtSearchDB;
        private System.Windows.Forms.Button CmdDeleteCustomer;
        private System.Windows.Forms.Button CmdModifyCustomer;
        private System.Windows.Forms.Button CmdCreateCustomer;
        private System.Windows.Forms.Label LblDashboard;
        private System.Windows.Forms.DataGridView GrdArt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPreis;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtArtName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtArtNr;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.BindingSource articelsBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn artikelNrDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bezeichnungDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn preisDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn artikelGruppeDataGridViewTextBoxColumn;
        private System.Windows.Forms.ComboBox CmbArtGroup;
        private System.Windows.Forms.BindingSource articelsgruppsBindingSource;
    }
}