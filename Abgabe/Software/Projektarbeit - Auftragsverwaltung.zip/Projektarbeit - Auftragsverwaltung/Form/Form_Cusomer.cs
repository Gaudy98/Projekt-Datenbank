﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using Projektarbeit___Auftragsverwaltung.Model;

namespace Projektarbeit___Auftragsverwaltung
{
    public partial class Form_Customer : Form
    {
        private Form_Dashbord form_Dashbord;
        Customer model = new Customer();


        public Form_Customer(Form_Dashbord frm_Dashbord)
        {
            InitializeComponent();
            this.form_Dashbord = frm_Dashbord;
        }

        void Clear()
        {
            txtCustomerName.Text = txtCustomerAdress.Text = txtCustomerMail.Text = txtCustomerNr.Text =
                txtCustomerOrt.Text = txtCustomerPLZ
                    .Text = txtCustomerPW.Text = txtCustomerWebsite.Text = " ";
        }

        private void LblDashboard_Click(object sender, EventArgs e)
        {
            form_Dashbord.Show();
            this.Close();
        }

        private void Form_Customer_Load_1(object sender, EventArgs e)
        {
            Clear();
            PopulateDataGridView();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            form_Dashbord.Show();
            base.OnFormClosing(e);
        }



        private void CmdCreateCustomer_Click(object sender, EventArgs e)
        {
            using (var Context = new CourseContext())
            {
                var model = new Customer();

                model.KundenNr = Convert.ToInt16(txtCustomerNr.Text.Trim());
                model.Name = txtCustomerName.Text.Trim();
                model.Strasse = txtCustomerAdress.Text.Trim();
                model.PLZ = Convert.ToInt16(txtCustomerPLZ.Text.Trim());
                model.Mail = txtCustomerMail.Text.Trim();
                model.Website = txtCustomerWebsite.Text.Trim();
                model.Passwort = txtCustomerPW.Text.Trim();


                Context.Customers.Add(model);
                Context.SaveChanges();

                Clear();
                MessageBox.Show("Submtted Succesfully");

                PopulateDataGridView();
            }

        }

        void PopulateDataGridView()
        {
            using (var Context = new CourseContext())
            {
                GrdCustomer.DataSource = Context.Customers.ToList<Customer>();

            }
        }

        private void GrdCustomer_DoubleClick(object sender, EventArgs e)
        {
            int index = GrdCustomer.CurrentCell.RowIndex;

            using (var context = new CourseContext())
            {
                var customer = context.Customers.Find(index);

                model.Name = txtCustomerName.Text.Trim();
                model.Strasse = txtCustomerAdress.Text.Trim();
                //model.PLZ = Convert.ToInt16(txtCustomerPLZ.Text.Trim());
                model.Mail = txtCustomerMail.Text.Trim();
                model.Website = txtCustomerWebsite.Text.Trim();
                model.Passwort = txtCustomerPW.Text.Trim();

                context.SaveChanges();
                //MessageBox.Show("Chances");
                PopulateDataGridView();

            }
            
        }

        private void CmdModifyCustomer_Click(object sender, EventArgs e)
        {
           /* int index = GrdCustomer.CurrentCell.RowIndex;

            using (var context = new CourseContext())
            {
                model = context.Customers.Find(index);

                //model.KundenNr = Convert.ToInt16(txtCustomerNr.Text.Trim());
                model.Name = txtCustomerName.Text.Trim();
                model.Strasse = txtCustomerAdress.Text.Trim();
                //model.PLZ = Convert.ToInt16(txtCustomerPLZ.Text.Trim());
                model.Mail = txtCustomerMail.Text.Trim();
                model.Website = txtCustomerWebsite.Text.Trim();
                model.Passwort = txtCustomerPW.Text.Trim();

                PopulateDataGridView();
                //MessageBox.Show("Delate");

            }

            
            /*using (var Context = new CourseContext())
            {

                Context.Customers.Add(model);

                Context.SaveChanges();
                //Clear();
                MessageBox.Show("Chances");
            }*/

        }

        private void CmdDeleteCustomer_Click(object sender, EventArgs e)
        {
            int index = GrdCustomer.CurrentCell.RowIndex;

            using (var context = new CourseContext())
            {
                var customer = context.Customers.Find(index);
                context.Customers.Remove(customer);
                context.SaveChanges();

                PopulateDataGridView();
                MessageBox.Show("Delate");

            }
        }


        private void Cmd_Search_Click(object sender, EventArgs e)
        {
            /*//Search Function
            (GrdCustomer.DataSource as DataTable).DefaultView.RowFilter = String.Format(
                "Convert(EmployeeNumber, System.String) LIKE '%{0}%' OR " +
                "CustomerNr '%{0}%' OR " +
                "Name LIKE '%{0}%' OR " +
                "Adress LIKE '%{0}%' OR " +
                "`PLZ` LIKE '%{0}%' OR " +
                "Ort LIKE '%{0}%' OR " +
                "Mail LIKE '%{0}%' OR " +
                "Website LIKE '%{0}%' OR " +
                "Password LIKE '%{0}%' OR "
                , TxtSearchDB.Text);*/
        }

        private void TxtSearchDB_TextChanged(object sender, EventArgs e)
        {
           /* //Search Function
            (GrdCustomer.DataSource as DataTable).DefaultView.RowFilter = String.Format(
                "Convert(EmployeeNumber, System.String) LIKE '%{0}%' OR " +
                "CustomerNr '%{0}%' OR " +
                "Name LIKE '%{0}%' OR " +
                "Adress LIKE '%{0}%' OR " +
                "`PLZ` LIKE '%{0}%' OR " +
                "Ort LIKE '%{0}%' OR " +
                "Mail LIKE '%{0}%' OR " +
                "Website LIKE '%{0}%' OR " +
                "Password LIKE '%{0}%' OR "
                , TxtSearchDB.Text);*/
        }
    }
}
