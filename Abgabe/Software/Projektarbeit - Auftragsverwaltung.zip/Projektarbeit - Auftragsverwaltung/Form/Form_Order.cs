﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Projektarbeit___Auftragsverwaltung.Model;

namespace Projektarbeit___Auftragsverwaltung
{
    public partial class Form_Order : Form
    {
        private Form_Dashbord form_Dashbord;
        Order model = new Order();

        public Form_Order(Form_Dashbord form_Dashbord)
        {
            InitializeComponent();
            this.form_Dashbord = form_Dashbord;
            
        }

        void Clear()
        {
            txtOrdernum.Text = txtDate.Text = txtOrderNr.Text = txtOrderPosition.Text = " ";
        }

        private void LblDashboard_Click(object sender, EventArgs e)
        {
            form_Dashbord.Show();
            this.Close();
        }

        private void Form_Order_Load(object sender, EventArgs e)
        {
            Clear();
            PopulateDataGridView();
            
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            form_Dashbord.Show();
            base.OnFormClosing(e);
        }

        private void CmdCreateCustomer_Click(object sender, EventArgs e)
        {
            using (var Context = new CourseContext())
            {
                var model = new Order();

                model.Auftragsnummer = Convert.ToInt16(txtOrderNr.Text.Trim());
                model.Date = Convert.ToDateTime(txtDate.Text.Trim());
                model.PositionNum = Convert.ToInt16(txtOrderPosition.Text.Trim());
                model.Anzahl = Convert.ToInt16(txtOrdernum.Text.Trim());

                Context.Orders.Add(model);
                Context.SaveChanges();

                Clear();
                MessageBox.Show("Submtted Succesfully");

                PopulateDataGridView();
            }
        }

        void PopulateDataGridView()
        {
            using (var Context = new CourseContext())
            {
                GrdOrder.DataSource = Context.Orders.ToList<Order>();
            }
        }


        private void CmdDeleteCustomer_Click(object sender, EventArgs e)
        {
            int index = GrdOrder.CurrentCell.RowIndex;

            using (var context = new CourseContext())
            {
                var order = context.Orders.Find(index);
                context.Orders.Remove(order);
                context.SaveChanges();

                PopulateDataGridView();
                MessageBox.Show("Delate");

            }
        }

        private void CmbArticels_SelectedIndexChanged(object sender, EventArgs e)
        {
            using (var Context = new CourseContext())
            {
                GrdOrder.DataSource = Context.Articels.ToList<Articels>();
            }
        }

        private void CmbCustomer_SelectedIndexChanged(object sender, EventArgs e)
        {
            using (var Context = new CourseContext())
            {
                GrdOrder.DataSource = Context.Customers.ToList<Customer>();
            }
        }
    }
}
