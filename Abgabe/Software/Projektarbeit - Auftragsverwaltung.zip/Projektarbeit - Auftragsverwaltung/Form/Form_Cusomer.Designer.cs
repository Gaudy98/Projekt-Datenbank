﻿
namespace Projektarbeit___Auftragsverwaltung
{
    partial class Form_Customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.LblDashboard = new System.Windows.Forms.Label();
            this.CmdDeleteCustomer = new System.Windows.Forms.Button();
            this.CmdModifyCustomer = new System.Windows.Forms.Button();
            this.CmdCreateCustomer = new System.Windows.Forms.Button();
            this.TxtSearchDB = new System.Windows.Forms.TextBox();
            this.txtCustomerPW = new System.Windows.Forms.TextBox();
            this.customerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label8 = new System.Windows.Forms.Label();
            this.txtCustomerWebsite = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCustomerMail = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCustomerOrt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtCustomerPLZ = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCustomerAdress = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCustomerNr = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.GrdCustomer = new System.Windows.Forms.DataGridView();
            this.kundenNrDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.strasseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pLZDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ortDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.websiteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passwortDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cmd_Search = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GrdCustomer)).BeginInit();
            this.SuspendLayout();
            // 
            // LblDashboard
            // 
            this.LblDashboard.AutoSize = true;
            this.LblDashboard.BackColor = System.Drawing.Color.Transparent;
            this.LblDashboard.Font = new System.Drawing.Font("Rage Italic", 20.1F, System.Drawing.FontStyle.Bold);
            this.LblDashboard.ForeColor = System.Drawing.Color.Gray;
            this.LblDashboard.Location = new System.Drawing.Point(41, 59);
            this.LblDashboard.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.LblDashboard.Name = "LblDashboard";
            this.LblDashboard.Size = new System.Drawing.Size(300, 86);
            this.LblDashboard.TabIndex = 36;
            this.LblDashboard.Text = "Dashboard";
            this.LblDashboard.UseMnemonic = false;
            this.LblDashboard.Click += new System.EventHandler(this.LblDashboard_Click);
            // 
            // CmdDeleteCustomer
            // 
            this.CmdDeleteCustomer.Location = new System.Drawing.Point(606, 894);
            this.CmdDeleteCustomer.Name = "CmdDeleteCustomer";
            this.CmdDeleteCustomer.Size = new System.Drawing.Size(236, 48);
            this.CmdDeleteCustomer.TabIndex = 39;
            this.CmdDeleteCustomer.Text = "Delete Selected";
            this.CmdDeleteCustomer.UseVisualStyleBackColor = true;
            this.CmdDeleteCustomer.Click += new System.EventHandler(this.CmdDeleteCustomer_Click);
            // 
            // CmdModifyCustomer
            // 
            this.CmdModifyCustomer.Location = new System.Drawing.Point(342, 894);
            this.CmdModifyCustomer.Name = "CmdModifyCustomer";
            this.CmdModifyCustomer.Size = new System.Drawing.Size(239, 48);
            this.CmdModifyCustomer.TabIndex = 38;
            this.CmdModifyCustomer.Text = "Save Changes";
            this.CmdModifyCustomer.UseVisualStyleBackColor = true;
            this.CmdModifyCustomer.Click += new System.EventHandler(this.CmdModifyCustomer_Click);
            // 
            // CmdCreateCustomer
            // 
            this.CmdCreateCustomer.Location = new System.Drawing.Point(56, 894);
            this.CmdCreateCustomer.Name = "CmdCreateCustomer";
            this.CmdCreateCustomer.Size = new System.Drawing.Size(246, 48);
            this.CmdCreateCustomer.TabIndex = 37;
            this.CmdCreateCustomer.Text = "Add New Customer";
            this.CmdCreateCustomer.UseVisualStyleBackColor = true;
            this.CmdCreateCustomer.Click += new System.EventHandler(this.CmdCreateCustomer_Click);
            // 
            // TxtSearchDB
            // 
            this.TxtSearchDB.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Bold);
            this.TxtSearchDB.Location = new System.Drawing.Point(649, 74);
            this.TxtSearchDB.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.TxtSearchDB.Name = "TxtSearchDB";
            this.TxtSearchDB.Size = new System.Drawing.Size(862, 71);
            this.TxtSearchDB.TabIndex = 45;
            this.TxtSearchDB.TextChanged += new System.EventHandler(this.TxtSearchDB_TextChanged);
            // 
            // txtCustomerPW
            // 
            this.txtCustomerPW.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource, "Passwort", true));
            this.txtCustomerPW.Location = new System.Drawing.Point(197, 719);
            this.txtCustomerPW.Name = "txtCustomerPW";
            this.txtCustomerPW.Size = new System.Drawing.Size(384, 38);
            this.txtCustomerPW.TabIndex = 55;
            // 
            // customerBindingSource
            // 
            this.customerBindingSource.DataSource = typeof(Projektarbeit___Auftragsverwaltung.Model.Customer);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(34, 725);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(131, 32);
            this.label8.TabIndex = 62;
            this.label8.Text = "Passwort";
            // 
            // txtCustomerWebsite
            // 
            this.txtCustomerWebsite.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource, "Website", true));
            this.txtCustomerWebsite.Location = new System.Drawing.Point(197, 641);
            this.txtCustomerWebsite.Name = "txtCustomerWebsite";
            this.txtCustomerWebsite.Size = new System.Drawing.Size(384, 38);
            this.txtCustomerWebsite.TabIndex = 54;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(34, 647);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(118, 32);
            this.label7.TabIndex = 61;
            this.label7.Text = "Website";
            // 
            // txtCustomerMail
            // 
            this.txtCustomerMail.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource, "Mail", true));
            this.txtCustomerMail.Location = new System.Drawing.Point(197, 568);
            this.txtCustomerMail.Name = "txtCustomerMail";
            this.txtCustomerMail.Size = new System.Drawing.Size(384, 38);
            this.txtCustomerMail.TabIndex = 53;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(34, 574);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 32);
            this.label6.TabIndex = 60;
            this.label6.Text = "E-Mail";
            // 
            // txtCustomerOrt
            // 
            this.txtCustomerOrt.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource, "Ort", true));
            this.txtCustomerOrt.Location = new System.Drawing.Point(197, 496);
            this.txtCustomerOrt.Name = "txtCustomerOrt";
            this.txtCustomerOrt.Size = new System.Drawing.Size(384, 38);
            this.txtCustomerOrt.TabIndex = 52;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(34, 502);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 32);
            this.label5.TabIndex = 59;
            this.label5.Text = "Ort";
            // 
            // txtCustomerPLZ
            // 
            this.txtCustomerPLZ.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource, "PLZ", true));
            this.txtCustomerPLZ.Location = new System.Drawing.Point(197, 419);
            this.txtCustomerPLZ.Name = "txtCustomerPLZ";
            this.txtCustomerPLZ.Size = new System.Drawing.Size(384, 38);
            this.txtCustomerPLZ.TabIndex = 51;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(34, 425);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 32);
            this.label4.TabIndex = 58;
            this.label4.Text = "PLZ";
            // 
            // txtCustomerAdress
            // 
            this.txtCustomerAdress.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource, "Strasse", true));
            this.txtCustomerAdress.Location = new System.Drawing.Point(197, 343);
            this.txtCustomerAdress.Name = "txtCustomerAdress";
            this.txtCustomerAdress.Size = new System.Drawing.Size(384, 38);
            this.txtCustomerAdress.TabIndex = 50;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 349);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 32);
            this.label3.TabIndex = 57;
            this.label3.Text = "Strasse";
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource, "Name", true));
            this.txtCustomerName.Location = new System.Drawing.Point(197, 269);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(384, 38);
            this.txtCustomerName.TabIndex = 48;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 275);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 32);
            this.label2.TabIndex = 56;
            this.label2.Text = "Name";
            // 
            // txtCustomerNr
            // 
            this.txtCustomerNr.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource, "KundenNr", true));
            this.txtCustomerNr.Location = new System.Drawing.Point(197, 201);
            this.txtCustomerNr.Name = "txtCustomerNr";
            this.txtCustomerNr.Size = new System.Drawing.Size(384, 38);
            this.txtCustomerNr.TabIndex = 47;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(34, 207);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(143, 32);
            this.label9.TabIndex = 49;
            this.label9.Text = "KundenNr";
            // 
            // GrdCustomer
            // 
            this.GrdCustomer.AllowUserToAddRows = false;
            this.GrdCustomer.AllowUserToDeleteRows = false;
            this.GrdCustomer.AllowUserToOrderColumns = true;
            this.GrdCustomer.AutoGenerateColumns = false;
            this.GrdCustomer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GrdCustomer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.kundenNrDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.strasseDataGridViewTextBoxColumn,
            this.pLZDataGridViewTextBoxColumn,
            this.ortDataGridViewTextBoxColumn,
            this.mailDataGridViewTextBoxColumn,
            this.websiteDataGridViewTextBoxColumn,
            this.passwortDataGridViewTextBoxColumn});
            this.GrdCustomer.DataSource = this.customerBindingSource;
            this.GrdCustomer.Location = new System.Drawing.Point(626, 193);
            this.GrdCustomer.Name = "GrdCustomer";
            this.GrdCustomer.ReadOnly = true;
            this.GrdCustomer.RowHeadersWidth = 102;
            this.GrdCustomer.Size = new System.Drawing.Size(1414, 679);
            this.GrdCustomer.TabIndex = 34;
            this.GrdCustomer.DoubleClick += new System.EventHandler(this.GrdCustomer_DoubleClick);
            // 
            // kundenNrDataGridViewTextBoxColumn
            // 
            this.kundenNrDataGridViewTextBoxColumn.DataPropertyName = "KundenNr";
            this.kundenNrDataGridViewTextBoxColumn.HeaderText = "KundenNr";
            this.kundenNrDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.kundenNrDataGridViewTextBoxColumn.Name = "kundenNrDataGridViewTextBoxColumn";
            this.kundenNrDataGridViewTextBoxColumn.ReadOnly = true;
            this.kundenNrDataGridViewTextBoxColumn.Width = 12;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.ReadOnly = true;
            this.nameDataGridViewTextBoxColumn.Width = 250;
            // 
            // strasseDataGridViewTextBoxColumn
            // 
            this.strasseDataGridViewTextBoxColumn.DataPropertyName = "Strasse";
            this.strasseDataGridViewTextBoxColumn.HeaderText = "Strasse";
            this.strasseDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.strasseDataGridViewTextBoxColumn.Name = "strasseDataGridViewTextBoxColumn";
            this.strasseDataGridViewTextBoxColumn.ReadOnly = true;
            this.strasseDataGridViewTextBoxColumn.Width = 250;
            // 
            // pLZDataGridViewTextBoxColumn
            // 
            this.pLZDataGridViewTextBoxColumn.DataPropertyName = "PLZ";
            this.pLZDataGridViewTextBoxColumn.HeaderText = "PLZ";
            this.pLZDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.pLZDataGridViewTextBoxColumn.Name = "pLZDataGridViewTextBoxColumn";
            this.pLZDataGridViewTextBoxColumn.ReadOnly = true;
            this.pLZDataGridViewTextBoxColumn.Width = 250;
            // 
            // ortDataGridViewTextBoxColumn
            // 
            this.ortDataGridViewTextBoxColumn.DataPropertyName = "Ort";
            this.ortDataGridViewTextBoxColumn.HeaderText = "Ort";
            this.ortDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.ortDataGridViewTextBoxColumn.Name = "ortDataGridViewTextBoxColumn";
            this.ortDataGridViewTextBoxColumn.ReadOnly = true;
            this.ortDataGridViewTextBoxColumn.Width = 250;
            // 
            // mailDataGridViewTextBoxColumn
            // 
            this.mailDataGridViewTextBoxColumn.DataPropertyName = "Mail";
            this.mailDataGridViewTextBoxColumn.HeaderText = "Mail";
            this.mailDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.mailDataGridViewTextBoxColumn.Name = "mailDataGridViewTextBoxColumn";
            this.mailDataGridViewTextBoxColumn.ReadOnly = true;
            this.mailDataGridViewTextBoxColumn.Width = 250;
            // 
            // websiteDataGridViewTextBoxColumn
            // 
            this.websiteDataGridViewTextBoxColumn.DataPropertyName = "Website";
            this.websiteDataGridViewTextBoxColumn.HeaderText = "Website";
            this.websiteDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.websiteDataGridViewTextBoxColumn.Name = "websiteDataGridViewTextBoxColumn";
            this.websiteDataGridViewTextBoxColumn.ReadOnly = true;
            this.websiteDataGridViewTextBoxColumn.Width = 250;
            // 
            // passwortDataGridViewTextBoxColumn
            // 
            this.passwortDataGridViewTextBoxColumn.DataPropertyName = "Passwort";
            this.passwortDataGridViewTextBoxColumn.HeaderText = "Passwort";
            this.passwortDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.passwortDataGridViewTextBoxColumn.Name = "passwortDataGridViewTextBoxColumn";
            this.passwortDataGridViewTextBoxColumn.ReadOnly = true;
            this.passwortDataGridViewTextBoxColumn.Width = 250;
            // 
            // Cmd_Search
            // 
            this.Cmd_Search.Location = new System.Drawing.Point(1538, 78);
            this.Cmd_Search.Name = "Cmd_Search";
            this.Cmd_Search.Size = new System.Drawing.Size(264, 66);
            this.Cmd_Search.TabIndex = 64;
            this.Cmd_Search.Text = "Suche";
            this.Cmd_Search.UseVisualStyleBackColor = true;
            this.Cmd_Search.Click += new System.EventHandler(this.Cmd_Search_Click);
            // 
            // Form_Customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2118, 1063);
            this.Controls.Add(this.Cmd_Search);
            this.Controls.Add(this.txtCustomerPW);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtCustomerWebsite);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtCustomerMail);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtCustomerOrt);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtCustomerPLZ);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtCustomerAdress);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtCustomerName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtCustomerNr);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.TxtSearchDB);
            this.Controls.Add(this.CmdDeleteCustomer);
            this.Controls.Add(this.CmdModifyCustomer);
            this.Controls.Add(this.CmdCreateCustomer);
            this.Controls.Add(this.LblDashboard);
            this.Controls.Add(this.GrdCustomer);
            this.Name = "Form_Customer";
            this.Text = "Kunden";
            this.Load += new System.EventHandler(this.Form_Customer_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GrdCustomer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button CmdDeleteCustomer;
        private System.Windows.Forms.Button CmdModifyCustomer;
        private System.Windows.Forms.Button CmdCreateCustomer;
        private System.Windows.Forms.TextBox TxtSearchDB;
        private System.Windows.Forms.Label LblDashboard;
        private System.Windows.Forms.BindingSource customerBindingSource;
        private System.Windows.Forms.TextBox txtCustomerPW;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtCustomerWebsite;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCustomerMail;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtCustomerOrt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtCustomerPLZ;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCustomerAdress;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCustomerNr;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridView GrdCustomer;
        private System.Windows.Forms.DataGridViewTextBoxColumn kundenNrDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn strasseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pLZDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ortDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn websiteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn passwortDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button Cmd_Search;
    }
}