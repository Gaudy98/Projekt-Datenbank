﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projektarbeit___Auftragsverwaltung
{
    public partial class Form_Articels : Form
    {
        private Form_Dashbord form_Dashbord;

        public Form_Articels(Form_Dashbord form_Dashbord)
        {
            InitializeComponent();
            this.form_Dashbord = form_Dashbord;
        }

        private void LblDashboard_Click(object sender, EventArgs e)
        {
            form_Dashbord.Show();
            this.Close();
        }

        void Clear()
        {
           txtArtName.Text = txtArtNr.Text = txtPreis.Text = " ";
        }

        private void Form_Articels_Load(object sender, EventArgs e)
        {
            Clear();
            PopulateDataGridView();
            CmbArtGroup.SelectedValue.ToString();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            form_Dashbord.Show();
            base.OnFormClosing(e);
        }

        private void CmdCreateCustomer_Click(object sender, EventArgs e)
        {
            using (var Context = new CourseContext())
            {
                var model = new Articels();

                model.ArtikelNr = Convert.ToInt16(txtArtNr.Text.Trim());
                model.Bezeichnung = txtArtName.Text.Trim();
                model.Preis = Convert.ToInt16(txtPreis.Text.Trim());
                //model.Articelsgrupps = txtArtGroupSel.Text.Trim());
                
                Context.Articels.Add(model);
                Context.SaveChanges();

                Clear();
                MessageBox.Show("Submtted Succesfully");

                PopulateDataGridView();
            }
        }

        void PopulateDataGridView()
        {
            using (var Context = new CourseContext())
            {
                GrdArt.DataSource = Context.Articels.ToList<Articels>();

            }
        }

        private void CmdDeleteCustomer_Click(object sender, EventArgs e)
        {
            int index = GrdArt.CurrentCell.RowIndex;

            using (var context = new CourseContext())
            {
                var artikel = context.Articels.Find(index);
                context.Articels.Remove(artikel);
                context.SaveChanges();

                PopulateDataGridView();
                MessageBox.Show("Delate");

            }
        }
    }
}
