﻿
namespace Projektarbeit___Auftragsverwaltung
{
    partial class Form_Quartal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.GrdQuartal = new System.Windows.Forms.DataGridView();
            this.quartalBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.anzahlAuftraegeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.verwalteteArtDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.durchschnittArtProAuftragDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.umsatzProKundeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gesammtumsatzDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.GrdQuartal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.quartalBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // GrdQuartal
            // 
            this.GrdQuartal.AllowUserToAddRows = false;
            this.GrdQuartal.AllowUserToDeleteRows = false;
            this.GrdQuartal.AutoGenerateColumns = false;
            this.GrdQuartal.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GrdQuartal.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.anzahlAuftraegeDataGridViewTextBoxColumn,
            this.verwalteteArtDataGridViewTextBoxColumn,
            this.durchschnittArtProAuftragDataGridViewTextBoxColumn,
            this.umsatzProKundeDataGridViewTextBoxColumn,
            this.gesammtumsatzDataGridViewTextBoxColumn});
            this.GrdQuartal.DataSource = this.quartalBindingSource;
            this.GrdQuartal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GrdQuartal.Location = new System.Drawing.Point(0, 0);
            this.GrdQuartal.Name = "GrdQuartal";
            this.GrdQuartal.ReadOnly = true;
            this.GrdQuartal.RowHeadersWidth = 102;
            this.GrdQuartal.Size = new System.Drawing.Size(2077, 856);
            this.GrdQuartal.TabIndex = 35;
            // 
            // quartalBindingSource
            // 
            this.quartalBindingSource.DataSource = typeof(Projektarbeit___Auftragsverwaltung.Quartal);
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            this.idDataGridViewTextBoxColumn.Width = 250;
            // 
            // anzahlAuftraegeDataGridViewTextBoxColumn
            // 
            this.anzahlAuftraegeDataGridViewTextBoxColumn.DataPropertyName = "Anzahl_Auftraege";
            this.anzahlAuftraegeDataGridViewTextBoxColumn.HeaderText = "Anzahl_Auftraege";
            this.anzahlAuftraegeDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.anzahlAuftraegeDataGridViewTextBoxColumn.Name = "anzahlAuftraegeDataGridViewTextBoxColumn";
            this.anzahlAuftraegeDataGridViewTextBoxColumn.ReadOnly = true;
            this.anzahlAuftraegeDataGridViewTextBoxColumn.Width = 250;
            // 
            // verwalteteArtDataGridViewTextBoxColumn
            // 
            this.verwalteteArtDataGridViewTextBoxColumn.DataPropertyName = "verwalteteArt";
            this.verwalteteArtDataGridViewTextBoxColumn.HeaderText = "verwalteteArt";
            this.verwalteteArtDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.verwalteteArtDataGridViewTextBoxColumn.Name = "verwalteteArtDataGridViewTextBoxColumn";
            this.verwalteteArtDataGridViewTextBoxColumn.ReadOnly = true;
            this.verwalteteArtDataGridViewTextBoxColumn.Width = 250;
            // 
            // durchschnittArtProAuftragDataGridViewTextBoxColumn
            // 
            this.durchschnittArtProAuftragDataGridViewTextBoxColumn.DataPropertyName = "DurchschnittArtProAuftrag";
            this.durchschnittArtProAuftragDataGridViewTextBoxColumn.HeaderText = "DurchschnittArtProAuftrag";
            this.durchschnittArtProAuftragDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.durchschnittArtProAuftragDataGridViewTextBoxColumn.Name = "durchschnittArtProAuftragDataGridViewTextBoxColumn";
            this.durchschnittArtProAuftragDataGridViewTextBoxColumn.ReadOnly = true;
            this.durchschnittArtProAuftragDataGridViewTextBoxColumn.Width = 250;
            // 
            // umsatzProKundeDataGridViewTextBoxColumn
            // 
            this.umsatzProKundeDataGridViewTextBoxColumn.DataPropertyName = "UmsatzProKunde";
            this.umsatzProKundeDataGridViewTextBoxColumn.HeaderText = "UmsatzProKunde";
            this.umsatzProKundeDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.umsatzProKundeDataGridViewTextBoxColumn.Name = "umsatzProKundeDataGridViewTextBoxColumn";
            this.umsatzProKundeDataGridViewTextBoxColumn.ReadOnly = true;
            this.umsatzProKundeDataGridViewTextBoxColumn.Width = 250;
            // 
            // gesammtumsatzDataGridViewTextBoxColumn
            // 
            this.gesammtumsatzDataGridViewTextBoxColumn.DataPropertyName = "Gesammtumsatz";
            this.gesammtumsatzDataGridViewTextBoxColumn.HeaderText = "Gesammtumsatz";
            this.gesammtumsatzDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.gesammtumsatzDataGridViewTextBoxColumn.Name = "gesammtumsatzDataGridViewTextBoxColumn";
            this.gesammtumsatzDataGridViewTextBoxColumn.ReadOnly = true;
            this.gesammtumsatzDataGridViewTextBoxColumn.Width = 250;
            // 
            // Form_Quartal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2077, 856);
            this.Controls.Add(this.GrdQuartal);
            this.Name = "Form_Quartal";
            this.Text = "Form_Quartal";
            ((System.ComponentModel.ISupportInitialize)(this.GrdQuartal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.quartalBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView GrdQuartal;
        private System.Windows.Forms.BindingSource quartalBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn anzahlAuftraegeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn verwalteteArtDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn durchschnittArtProAuftragDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn umsatzProKundeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gesammtumsatzDataGridViewTextBoxColumn;
    }
}