﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projektarbeit___Auftragsverwaltung
{
    public partial class Form_Dashbord : Form
    {
        public Form_Dashbord()
        {
            InitializeComponent();
        }

        private void Cmd_Order_Click(object sender, EventArgs e)
        {
            Form_Order frmOrder = new Form_Order(this);
            frmOrder.Show();
            this.Hide();
        }

        private void Cmd_Customer_Click(object sender, EventArgs e)
        {
            Form_Customer frmCustomer = new Form_Customer(this);
            frmCustomer.Show();
            this.Hide();
        }

        private void Cmd_Artikelgruppen_Click(object sender, EventArgs e)
        {
            Form_ArticelsGruppe frmArtikerlgrupp = new Form_ArticelsGruppe(this);
            frmArtikerlgrupp.Show();
            this.Hide();
        }

        private void Cmd_Artikel_Click(object sender, EventArgs e)
        {
            Form_Articels frmArticel = new Form_Articels(this);
            frmArticel.Show();
            this.Hide();
        }



        private void Cmd_TreeView_Click(object sender, EventArgs e)
        {
           

        }

        private void Cmd_Quartal_Click(object sender, EventArgs e)
        {
            Form_Quartal frmQuartal = new Form_Quartal();
            frmQuartal.Show();
            this.Hide();
        }
    }

}