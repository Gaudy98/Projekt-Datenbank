﻿
namespace Projektarbeit___Auftragsverwaltung
{
    partial class Form_ArticelsGruppe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.TxtSearchDB = new System.Windows.Forms.TextBox();
            this.CmdDeleteCustomer = new System.Windows.Forms.Button();
            this.CmdModifyCustomer = new System.Windows.Forms.Button();
            this.CmdCreateCustomer = new System.Windows.Forms.Button();
            this.LblDashboard = new System.Windows.Forms.Label();
            this.GrdArtGroup = new System.Windows.Forms.DataGridView();
            this.Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.TxtArticelGrup = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.articelsgruppsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.orderBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.GrdArtGroup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.articelsgruppsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // TxtSearchDB
            // 
            this.TxtSearchDB.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Bold);
            this.TxtSearchDB.Location = new System.Drawing.Point(680, 128);
            this.TxtSearchDB.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.TxtSearchDB.Name = "TxtSearchDB";
            this.TxtSearchDB.Size = new System.Drawing.Size(862, 71);
            this.TxtSearchDB.TabIndex = 52;
            // 
            // CmdDeleteCustomer
            // 
            this.CmdDeleteCustomer.Location = new System.Drawing.Point(718, 889);
            this.CmdDeleteCustomer.Name = "CmdDeleteCustomer";
            this.CmdDeleteCustomer.Size = new System.Drawing.Size(236, 48);
            this.CmdDeleteCustomer.TabIndex = 51;
            this.CmdDeleteCustomer.Text = "Delete Selected";
            this.CmdDeleteCustomer.UseVisualStyleBackColor = true;
            this.CmdDeleteCustomer.Click += new System.EventHandler(this.CmdDeleteCustomer_Click);
            // 
            // CmdModifyCustomer
            // 
            this.CmdModifyCustomer.Location = new System.Drawing.Point(414, 889);
            this.CmdModifyCustomer.Name = "CmdModifyCustomer";
            this.CmdModifyCustomer.Size = new System.Drawing.Size(239, 48);
            this.CmdModifyCustomer.TabIndex = 50;
            this.CmdModifyCustomer.Text = "Modify Selected";
            this.CmdModifyCustomer.UseVisualStyleBackColor = true;
            // 
            // CmdCreateCustomer
            // 
            this.CmdCreateCustomer.Location = new System.Drawing.Point(63, 889);
            this.CmdCreateCustomer.Name = "CmdCreateCustomer";
            this.CmdCreateCustomer.Size = new System.Drawing.Size(246, 48);
            this.CmdCreateCustomer.TabIndex = 49;
            this.CmdCreateCustomer.Text = "Add New Customer";
            this.CmdCreateCustomer.UseVisualStyleBackColor = true;
            this.CmdCreateCustomer.Click += new System.EventHandler(this.CmdCreateCustomer_Click);
            // 
            // LblDashboard
            // 
            this.LblDashboard.AutoSize = true;
            this.LblDashboard.BackColor = System.Drawing.Color.Transparent;
            this.LblDashboard.Font = new System.Drawing.Font("Rage Italic", 20.1F, System.Drawing.FontStyle.Bold);
            this.LblDashboard.ForeColor = System.Drawing.Color.DarkGray;
            this.LblDashboard.Location = new System.Drawing.Point(64, 69);
            this.LblDashboard.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.LblDashboard.Name = "LblDashboard";
            this.LblDashboard.Size = new System.Drawing.Size(300, 86);
            this.LblDashboard.TabIndex = 48;
            this.LblDashboard.Text = "Dashboard";
            this.LblDashboard.UseMnemonic = false;
            this.LblDashboard.Click += new System.EventHandler(this.LblDashboard_Click);
            // 
            // GrdArtGroup
            // 
            this.GrdArtGroup.AllowUserToAddRows = false;
            this.GrdArtGroup.AllowUserToDeleteRows = false;
            this.GrdArtGroup.AutoGenerateColumns = false;
            this.GrdArtGroup.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GrdArtGroup.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.Name});
            this.GrdArtGroup.DataSource = this.articelsgruppsBindingSource;
            this.GrdArtGroup.Location = new System.Drawing.Point(718, 291);
            this.GrdArtGroup.Name = "GrdArtGroup";
            this.GrdArtGroup.ReadOnly = true;
            this.GrdArtGroup.RowHeadersWidth = 102;
            this.GrdArtGroup.Size = new System.Drawing.Size(1344, 498);
            this.GrdArtGroup.TabIndex = 47;
            // 
            // Name
            // 
            this.Name.DataPropertyName = "Name";
            this.Name.HeaderText = "Name";
            this.Name.MinimumWidth = 12;
            this.Name.Name = "Name";
            this.Name.ReadOnly = true;
            this.Name.Width = 250;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(674, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 32);
            this.label1.TabIndex = 54;
            this.label1.Text = "Suche";
            // 
            // TxtArticelGrup
            // 
            this.TxtArticelGrup.Location = new System.Drawing.Point(236, 404);
            this.TxtArticelGrup.Name = "TxtArticelGrup";
            this.TxtArticelGrup.Size = new System.Drawing.Size(384, 38);
            this.TxtArticelGrup.TabIndex = 66;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(73, 410);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 32);
            this.label9.TabIndex = 67;
            this.label9.Text = "Name";
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            this.idDataGridViewTextBoxColumn.Width = 250;
            // 
            // articelsgruppsBindingSource
            // 
            this.articelsgruppsBindingSource.DataSource = typeof(Projektarbeit___Auftragsverwaltung.Model.Articelsgrupps);
            // 
            // orderBindingSource
            // 
            this.orderBindingSource.DataSource = typeof(Projektarbeit___Auftragsverwaltung.Model.Order);
            // 
            // Form_ArticelsGruppe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2114, 1020);
            this.Controls.Add(this.TxtArticelGrup);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TxtSearchDB);
            this.Controls.Add(this.CmdDeleteCustomer);
            this.Controls.Add(this.CmdModifyCustomer);
            this.Controls.Add(this.CmdCreateCustomer);
            this.Controls.Add(this.LblDashboard);
            this.Controls.Add(this.GrdArtGroup);
            this.Text = "Artikerlgruppen";
            this.Load += new System.EventHandler(this.Form_ArticelsGruppe_Load);
            ((System.ComponentModel.ISupportInitialize)(this.GrdArtGroup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.articelsgruppsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox TxtSearchDB;
        private System.Windows.Forms.Button CmdDeleteCustomer;
        private System.Windows.Forms.Button CmdModifyCustomer;
        private System.Windows.Forms.Button CmdCreateCustomer;
        private System.Windows.Forms.Label LblDashboard;
        private System.Windows.Forms.DataGridView GrdArtGroup;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TxtArticelGrup;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.BindingSource orderBindingSource;
        private System.Windows.Forms.BindingSource articelsgruppsBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Name;
    }
}