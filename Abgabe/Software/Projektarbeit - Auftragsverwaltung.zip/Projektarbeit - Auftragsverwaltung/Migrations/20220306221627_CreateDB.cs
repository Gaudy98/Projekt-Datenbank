﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Projektarbeit___Auftragsverwaltung.Migrations
{
    public partial class CreateDB : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Articelsgrupps",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Articelsgrupps", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Customers",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    KundenNr = table.Column<int>(nullable: false),
                    Name = table.Column<string>(nullable: true),
                    Strasse = table.Column<string>(nullable: true),
                    PLZ = table.Column<int>(nullable: false),
                    Ort = table.Column<string>(nullable: true),
                    Mail = table.Column<string>(nullable: true),
                    Website = table.Column<string>(nullable: true),
                    Passwort = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Articels",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ArtikelNr = table.Column<int>(nullable: false),
                    Bezeichnung = table.Column<string>(nullable: true),
                    Preis = table.Column<decimal>(nullable: false),
                    ArtikelGruppeId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Articels", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Articels_Articelsgrupps_ArtikelGruppeId",
                        column: x => x.ArtikelGruppeId,
                        principalTable: "Articelsgrupps",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Orders",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Auftragsnummer = table.Column<int>(nullable: false),
                    Date = table.Column<DateTime>(nullable: false),
                    Customer = table.Column<string>(nullable: true),
                    PositionNum = table.Column<int>(nullable: false),
                    ArtikelId = table.Column<int>(nullable: true),
                    Anzahl = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Orders", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Orders_Articels_ArtikelId",
                        column: x => x.ArtikelId,
                        principalTable: "Articels",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Articels_ArtikelGruppeId",
                table: "Articels",
                column: "ArtikelGruppeId");

            migrationBuilder.CreateIndex(
                name: "IX_Orders_ArtikelId",
                table: "Orders",
                column: "ArtikelId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Customers");

            migrationBuilder.DropTable(
                name: "Orders");

            migrationBuilder.DropTable(
                name: "Articels");

            migrationBuilder.DropTable(
                name: "Articelsgrupps");
        }
    }
}
