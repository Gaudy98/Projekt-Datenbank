﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Projektarbeit___Auftragsverwaltung.Migrations
{
    public partial class Artikelgruppe : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Articels_Articelsgrupps_ArtikelGruppeId",
                table: "Articels");

            migrationBuilder.DropForeignKey(
                name: "FK_Orders_Articels_ArtikelId",
                table: "Orders");

            migrationBuilder.DropIndex(
                name: "IX_Articels_ArtikelGruppeId",
                table: "Articels");

            migrationBuilder.AlterColumn<int>(
                name: "Customer",
                table: "Orders",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ArticelsgruppsId",
                table: "Articels",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "Articelsgrupps1",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Articelsgrupps1", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Orders1",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Auftragsnummer = table.Column<int>(nullable: false),
                    Date = table.Column<DateTime>(nullable: false),
                    Customer = table.Column<string>(nullable: true),
                    PositionNum = table.Column<int>(nullable: false),
                    ArtikelId = table.Column<int>(nullable: true),
                    Anzahl = table.Column<int>(nullable: false),
                    ArticelsId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Orders1", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Orders1_Articels_ArticelsId",
                        column: x => x.ArticelsId,
                        principalTable: "Articels",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Articels1",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ArtikelNr = table.Column<int>(nullable: false),
                    Bezeichnung = table.Column<string>(nullable: true),
                    Preis = table.Column<decimal>(nullable: false),
                    ArtikelGruppeId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Articels1", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Articels1_Articelsgrupps1_ArtikelGruppeId",
                        column: x => x.ArtikelGruppeId,
                        principalTable: "Articelsgrupps1",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Articels_ArticelsgruppsId",
                table: "Articels",
                column: "ArticelsgruppsId");

            migrationBuilder.CreateIndex(
                name: "IX_Articels1_ArtikelGruppeId",
                table: "Articels1",
                column: "ArtikelGruppeId");

            migrationBuilder.CreateIndex(
                name: "IX_Orders1_ArticelsId",
                table: "Orders1",
                column: "ArticelsId");

            migrationBuilder.AddForeignKey(
                name: "FK_Articels_Articelsgrupps_ArticelsgruppsId",
                table: "Articels",
                column: "ArticelsgruppsId",
                principalTable: "Articelsgrupps",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Orders_Articels1_ArtikelId",
                table: "Orders",
                column: "ArtikelId",
                principalTable: "Articels1",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Articels_Articelsgrupps_ArticelsgruppsId",
                table: "Articels");

            migrationBuilder.DropForeignKey(
                name: "FK_Orders_Articels1_ArtikelId",
                table: "Orders");

            migrationBuilder.DropTable(
                name: "Articels1");

            migrationBuilder.DropTable(
                name: "Orders1");

            migrationBuilder.DropTable(
                name: "Articelsgrupps1");

            migrationBuilder.DropIndex(
                name: "IX_Articels_ArticelsgruppsId",
                table: "Articels");

            migrationBuilder.DropColumn(
                name: "ArticelsgruppsId",
                table: "Articels");

            migrationBuilder.AlterColumn<string>(
                name: "Customer",
                table: "Orders",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(int));

            migrationBuilder.CreateIndex(
                name: "IX_Articels_ArtikelGruppeId",
                table: "Articels",
                column: "ArtikelGruppeId");

            migrationBuilder.AddForeignKey(
                name: "FK_Articels_Articelsgrupps_ArtikelGruppeId",
                table: "Articels",
                column: "ArtikelGruppeId",
                principalTable: "Articelsgrupps",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Orders_Articels_ArtikelId",
                table: "Orders",
                column: "ArtikelId",
                principalTable: "Articels",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
