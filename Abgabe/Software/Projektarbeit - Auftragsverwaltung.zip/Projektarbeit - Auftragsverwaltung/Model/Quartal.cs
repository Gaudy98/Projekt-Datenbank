﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projektarbeit___Auftragsverwaltung
{
    class Quartal
    {
        public int Id { get; set; }
        public int Anzahl_Auftraege { get; set; }

        public int verwalteteArt { get; set; }
        public int DurchschnittArtProAuftrag { get; set; }
        public int UmsatzProKunde { get; set; }
        public int Gesammtumsatz { get; set; }
        
    }
}
