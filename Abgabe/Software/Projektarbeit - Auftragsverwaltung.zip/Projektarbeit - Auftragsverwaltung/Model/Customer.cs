﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projektarbeit___Auftragsverwaltung.Model
{
    public class Customer
    {
        public int Id { get; set; }
        public int KundenNr { get; set; }
        public string Name { get; set; }
        public string Strasse { get; set; }
        public int PLZ { get; set; }
        public string Ort { get; set; }
        public string Mail { get; set; }
        public string Website { get; set; }
        public string Passwort { get; set; }
    }
}
