﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projektarbeit___Auftragsverwaltung.Model
{
    public class Order
    {
        public int Id { get; set; }
        public int Auftragsnummer { get; set; }
 
        public DateTime Date { get; set; }
        public virtual int Customer { get; set; }
        public int PositionNum { get; set; }
        public virtual Articels Artikel { get; set; }
        public int Anzahl { get; set; }
        

    }
}
